#ifndef INDEXER_H
#define INDEXER_H


#include <dirent.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "sorted-list.h"
#include "tokenizer.h"

#endif
